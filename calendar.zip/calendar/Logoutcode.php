<?php
include_once('link.php');
session_start();
$email = $_SESSION['email'];
?>
<link rel="stylesheet" type="text/css" href="stylefile.css">

<nav class="navbar navbar-default">
	<div class="container-fluid">


		
		<div class="dropdown navbar-right" id="right">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $email;?>
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
  	<li><a href="index.php">Bookings</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</div>

	</div>
</nav>
<div class="backImg" />
	<center>
		<h1>Booking Successfull</h1>
<h1>THANK YOU </h1>
	</center>
</div>