<!--
this is header file which is visible in registration and login page.
-->
<?php
include_once('link.php');

?>

<link rel="stylesheet" type="text/css" href="stylefile.css">
<div class="backImg" />
<nav class="navbar navbar-default">

	<div class="container-fluid">

		<!--<div class="navbar-header">
			<a href="#" class="navbar-brand">Registration Login</a>
		</div>-->

		<ul class="nav navbar-nav">
			<li><a href="registration.php"><b>REGISTER</b></a></li>
			<li><a href="login.php"><b>LOGIN</b></a></li>
		</ul>



	</div>

</nav>
